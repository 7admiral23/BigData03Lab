import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Random;

public class BucketingAlgorithm {
    static final String FILE_PATH = "D:\\Documents\\Landshut\\Big Data\\04Lab\\set_2M.txt";
    static final double EPSILON = 0.1;
    static final double DELTA = 0.05;
    static final int B = (int) (96 / (EPSILON * EPSILON));
    static final int K = (int) (35 * Math.log(1 / DELTA) / Math.log(2));
    static final int ITERATIONS = 10;

    public static void main(String[] args) throws IOException {
        int[] data = readData(FILE_PATH);
        double avgRelativeError = 0;

        for (int i = 0; i < ITERATIONS; i++) {
            int estimate = estimateCardinality(data, B, K);
            int trueCardinality = data.length;
            double relativeError = 100.0 * Math.abs(estimate - trueCardinality) / trueCardinality;
            avgRelativeError += relativeError;
        }

        avgRelativeError /= ITERATIONS;
        System.out.println("Average Relative Error: " + avgRelativeError + "%");
    }

    public static int[] readData(String filePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        HashSet<Integer> data = new HashSet<>();
        String line;

        while ((line = reader.readLine()) != null) {
            data.add(Integer.parseInt(line));
        }

        reader.close();
        return data.stream().mapToInt(Integer::intValue).toArray();
    }

    public static int estimateCardinality(int[] data, int b, int k) {
        int[][] buckets = new int[k][b];
        Random random = new Random();

        for (int number : data) {
            for (int i = 0; i < k; i++) {
                int hash = tabulationHash(number, random);
                buckets[i][hash % b]++;
            }
        }

        double Z = 0;
        for (int i = 0; i < k; i++) {
            int zeros = 0;
            for (int j = 0; j < b; j++) {
                if (buckets[i][j] == 0) {
                    zeros++;
                }
            }
            Z += (b * Math.log(b / (double) (b - zeros)));
        }

        Z /= k;
        return (int) (b * b / Z);
    }

    public static int tabulationHash(int x, Random random) {
        // Implementation of tabulation hashing
        int hash = random.nextInt();
        return hash ^ x;
    }
}
