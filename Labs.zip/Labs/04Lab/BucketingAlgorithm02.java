import java.io.*;
import java.util.*;

public class BucketingAlgorithm02 {
    private static final int TABLE_SIZE = 256;
    private static final int TABLES = 4;
    private static final String FILE_PATH = "D:\\Documents\\Landshut\\BigData\\Labs\\04Lab\\set_2M.txt";
    private static final int TRUE_CARDINALITY = 2000000;
    private static final int ITERATIONS = 10;

    public static void main(String[] args) throws IOException {
        runExperiment(0.1, 0.05);
        runExperiment(0.2, 0.05);
        runExperiment(0.1, 0.1);
    }

    private static void runExperiment(double epsilon, double delta) throws IOException {
        int b = (int) (96 / (epsilon * epsilon));
        int k = (int) (35 * Math.log(1 / delta) / Math.log(2));

        System.out.printf("Running experiment with epsilon=%.2f, delta=%.2f, b=%d, k=%d\n", epsilon, delta, b, k);

        double totalError = 0;
        long totalTime = 0;

        for (int i = 0; i < ITERATIONS; i++) {
            long startTime = System.currentTimeMillis();
            int estimate = estimateCardinality(b, k);
            long endTime = System.currentTimeMillis();

            double relativeError = 100.0 * Math.abs(estimate - TRUE_CARDINALITY) / TRUE_CARDINALITY;
            totalError += relativeError;
            totalTime += (endTime - startTime);

            System.out.printf("Iteration %d: Estimate=%d, Relative Error=%.2f%%, Time=%d ms\n", 
                              i + 1, estimate, relativeError, (endTime - startTime));
        }

        System.out.printf("Average Relative Error: %.2f%%\n", totalError / ITERATIONS);
        System.out.printf("Average Runtime: %d ms\n\n", totalTime / ITERATIONS);
    }

    private static int estimateCardinality(int b, int k) throws IOException {
        BitSet[] buckets = new BitSet[k];
        for (int i = 0; i < k; i++) {
            buckets[i] = new BitSet(b);
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                int x = Integer.parseInt(line);
                for (int i = 0; i < k; i++) {
                    int hash = tabulationHash(x, i);
                    int leadingZeros = Integer.numberOfLeadingZeros(hash);
                    if (leadingZeros < b) {
                        buckets[i].set(leadingZeros);
                    }
                }
            }
        }

        int[] zeroCounters = new int[k];
        for (int i = 0; i < k; i++) {
            zeroCounters[i] = buckets[i].nextClearBit(0);
        }

        Arrays.sort(zeroCounters);
        int median = (k % 2 == 0) ? (zeroCounters[k/2 - 1] + zeroCounters[k/2]) / 2 : zeroCounters[k/2];

        return (int) (Math.pow(2, median) * Math.log(2));
    }

    private static int tabulationHash(int x, int seed) {
        int[][] table = new int[TABLES][TABLE_SIZE];
        Random random = new Random(seed);
        for (int i = 0; i < TABLES; i++) {
            for (int j = 0; j < TABLE_SIZE; j++) {
                table[i][j] = random.nextInt();
            }
        }

        int hash = 0;
        for (int i = 0; i < TABLES; i++) {
            hash ^= table[i][(x >> (i * 8)) & 0xFF];
        }
        return hash;
    }
}