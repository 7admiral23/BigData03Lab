import java.io.*;
import java.util.*;

public class SuffixArrayLab {

    public static void main(String[] args) {
        try {
            // Read and preprocess the text
            String text = readAndPreprocessFile("D:\\Documents\\Landshut\\BigData\\Labs\\05Lab\\Mann_Buddenbrooks.txt");
            
            // Build suffix array
            long startTime = System.currentTimeMillis();
            int[] sa = buildSuffixArray(text);
            long endTime = System.currentTimeMillis();
            
            System.out.println("Suffix Array construction time: " + (endTime - startTime) + " ms");
            System.out.println("First three entries of SA: " + sa[0] + ", " + sa[1] + ", " + sa[2]);

            // Compute LCP array
            int[] lcp = computeLCP(text, sa);

            // Calculate average and maximum LCP
            int maxLcp = 0;
            long sumLcp = 0;
            for (int i = 1; i < lcp.length; i++) {
                maxLcp = Math.max(maxLcp, lcp[i]);
                sumLcp += lcp[i];
            }
            double avgLcp = (double) sumLcp / (lcp.length - 1);

            System.out.println("Maximum LCP: " + maxLcp);
            System.out.println("Average LCP: " + avgLcp);

            // Find longest supermaximal repeat
            int maxLcpIndex = 0;
            for (int i = 1; i < lcp.length; i++) {
                if (lcp[i] > lcp[maxLcpIndex]) {
                    maxLcpIndex = i;
                }
            }

            String longestRepeat = text.substring(sa[maxLcpIndex], sa[maxLcpIndex] + lcp[maxLcpIndex]);
            System.out.println("Longest supermaximal repeat: " + longestRepeat);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String readAndPreprocessFile(String filename) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line.toLowerCase().replace("\n", " "));
            }
        }
        sb.append("$"); // Add end marker
        return sb.toString();
    }

    public static int[] buildSuffixArray(String text) {
        int n = text.length();
        Integer[] sa = new Integer[n];
        
        for (int i = 0; i < n; i++) {
            sa[i] = i;
        }
        
        Arrays.sort(sa, (a, b) -> text.substring(a).compareTo(text.substring(b)));
        
        return Arrays.stream(sa).mapToInt(Integer::intValue).toArray();
    }

    public static int[] computeLCP(String text, int[] sa) {
        int n = text.length();
        int[] lcp = new int[n];
        int[] rank = new int[n];
        
        for (int i = 0; i < n; i++) {
            rank[sa[i]] = i;
        }
        
        int k = 0;
        for (int i = 0; i < n - 1; i++) {
            if (rank[i] > 0) {
                int j = sa[rank[i] - 1];
                while (i + k < n && j + k < n && text.charAt(i + k) == text.charAt(j + k)) {
                    k++;
                }
                lcp[rank[i]] = k;
                if (k > 0) k--;
            }
        }
        
        return lcp;
    }
}