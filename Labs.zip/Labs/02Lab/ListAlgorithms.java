import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class ListAlgorithms {
    private static final int ALPHABET_SIZE = 26;
    private static final String FILE_PATH = "D:\\Documents\\Landshut\\BigData\\Labs\\02Lab\\";

    public static void main(String[] args) throws IOException {
        String[] files = {"Requests_Toy.txt", "Requests_Exp.txt", "Requests_TM.txt"};

        for (String file : files) {
            System.out.println("Processing file: " + file);
            List<Character> requests = readRequests(FILE_PATH + file);
            double[] probabilities = computeProbabilities(requests);

            // Static lists
            double staticAlphaCost = computeStaticCost(probabilities, true);
            double staticProbaCost = computeStaticCost(probabilities, false);

            // MTF
            double mtfPredicted = predictMTFCost(probabilities);
            double mtfObserved = runMTF(requests);

            // BIT
            double bitObservedRandom = runBIT(requests, true);
            double bitObservedDeterministic = runBIT(requests, false);

            // Calculate deltas
            double deltaRandom = 100 * (bitObservedRandom - mtfObserved) / mtfObserved;
            double deltaDeterministic = 100 * (bitObservedDeterministic - mtfObserved) / mtfObserved;

            // Print results
            System.out.printf("Static (alpha): %.3f\n", staticAlphaCost);
            System.out.printf("Static (proba): %.3f\n", staticProbaCost);
            System.out.printf("MTF (predicted): %.3f\n", mtfPredicted);
            System.out.printf("MTF (observed): %.3f\n", mtfObserved);
            System.out.printf("BIT (random): %.3f\n", bitObservedRandom);
            System.out.printf("BIT (deterministic): %.3f\n", bitObservedDeterministic);
            System.out.printf("Delta (BIT random): %.3f%%\n", deltaRandom);
            System.out.printf("Delta (BIT deterministic): %.3f%%\n", deltaDeterministic);
            System.out.println();
        }
    }

    private static List<Character> readRequests(String filename) throws IOException {
        String content = new String(Files.readAllBytes(Paths.get(filename)));
        return content.chars().mapToObj(ch -> (char) ch)
                .filter(ch -> ch >= 'A' && ch <= 'Z').collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    private static double[] computeProbabilities(List<Character> requests) {
        int[] frequencies = new int[ALPHABET_SIZE];
        for (char c : requests) {
            frequencies[c - 'A']++;
        }
        double[] probabilities = new double[ALPHABET_SIZE];
        for (int i = 0; i < ALPHABET_SIZE; i++) {
            probabilities[i] = (double) frequencies[i] / requests.size();
        }
        return probabilities;
    }

    private static double computeStaticCost(double[] probabilities, boolean alphabetical) {
        double cost = 0;
        Integer[] indices = new Integer[ALPHABET_SIZE];
        for (int i = 0; i < ALPHABET_SIZE; i++) {
            indices[i] = i;
        }
        if (!alphabetical) {
            Arrays.sort(indices, (a, b) -> Double.compare(probabilities[b], probabilities[a]));
        }
        for (int i = 0; i < ALPHABET_SIZE; i++) {
            cost += (i + 1) * probabilities[indices[i]];
        }
        return cost;
    }

    private static double predictMTFCost(double[] probabilities) {
        double cost = 0.5;
        for (int i = 0; i < ALPHABET_SIZE; i++) {
            for (int j = i + 1; j < ALPHABET_SIZE; j++) {
                cost += 2 * probabilities[i] * probabilities[j] / (probabilities[i] + probabilities[j]);
            }
        }
        return cost;
    }

    private static double runMTF(List<Character> requests) {
        List<Character> list = new ArrayList<>();
        for (char c = 'A'; c <= 'Z'; c++) {
            list.add(c);
        }
        double totalCost = 0;
        for (char request : requests) {
            int index = list.indexOf(request);
            totalCost += index + 1;
            list.remove(index);
            list.add(0, request);
        }
        return totalCost / requests.size();
    }

    private static double runBIT(List<Character> requests, boolean randomInit) {
        List<Character> list = new ArrayList<>();
        boolean[] bits = new boolean[ALPHABET_SIZE];
        Random random = new Random();
        for (char c = 'A'; c <= 'Z'; c++) {
            list.add(c);
            bits[c - 'A'] = randomInit ? random.nextBoolean() : false;
        }
        double totalCost = 0;
        for (char request : requests) {
            int index = list.indexOf(request);
            totalCost += index + 1;
            for (int i = 0; i < index; i++) {
                if (bits[list.get(i) - 'A']) {
                    char temp = list.get(i);
                    list.set(i, request);
                    list.set(index, temp);
                    index = i;
                    break;
                }
            }
            bits[request - 'A'] = !bits[request - 'A'];
        }
        return totalCost / requests.size();
    }
}