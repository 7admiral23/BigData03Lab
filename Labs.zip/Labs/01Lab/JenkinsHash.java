import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class JenkinsHash {
    public static int hash(byte[] key) {
        int hash = 0;
        for (byte b : key) {
            hash += b & 0xFF;
            hash += (hash << 10);
            hash ^= (hash >>> 6);
        }
        hash += (hash << 3);
        hash ^= (hash >>> 11);
        hash += (hash << 15);
        return hash;
    }

    public static void main(String[] args) throws IOException {
        // Test with "BigData"
        String testInput = "BigData";
        int hashValue = hash(testInput.getBytes());
        System.out.println("Hash of 'BigData': " + Integer.toBinaryString(hashValue));

        // Test with file content
        String filePath = "D:\\Documents\\Landshut\\BigData\\Labs\\01Lab\\Mann_Buddenbrooks.txt";
        byte[] fileContent = Files.readAllBytes(Paths.get(filePath));
        
        // Remove newline and carriage return characters
        byte[] cleanedContent = new String(fileContent, "ISO-8859-1")
                                    .replaceAll("\\r\\n|\\r|\\n", "")
                                    .getBytes("ISO-8859-1");

        long startTime = System.nanoTime();
        int fileHashValue = hash(cleanedContent);
        long endTime = System.nanoTime();

        System.out.println("Number of characters: " + cleanedContent.length);
        System.out.println("Hash of file content: " + Integer.toBinaryString(fileHashValue));
        System.out.println("Time taken: " + ((endTime - startTime) / 1_000_000.0) + " ms");
    }
}