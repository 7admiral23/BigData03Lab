import java.util.Random;

public class TabulationHashing {
    private static final int TABLES = 4;
    private static final int TABLE_SIZE = 256;
    private static final int KEYS = 10_000_000;
    private static final int BITS = 32;

    private int[][] simpleTables;
    private int[][][] mixedTables;

    public TabulationHashing() {
        Random rand = new Random();
        
        // Initialize simple tabulation tables
        simpleTables = new int[TABLES][TABLE_SIZE];
        for (int i = 0; i < TABLES; i++) {
            for (int j = 0; j < TABLE_SIZE; j++) {
                simpleTables[i][j] = rand.nextInt();
            }
        }

        // Initialize mixed tabulation tables
        mixedTables = new int[TABLES][TABLE_SIZE][TABLES];
        for (int i = 0; i < TABLES; i++) {
            for (int j = 0; j < TABLE_SIZE; j++) {
                for (int k = 0; k < TABLES; k++) {
                    mixedTables[i][j][k] = rand.nextInt();
                }
            }
        }
    }

    public int simpleHash(int x) {
        int hash = 0;
        for (int i = 0; i < TABLES; i++) {
            hash ^= simpleTables[i][(x >> (i * 8)) & 0xFF];
        }
        return hash;
    }

    public int mixedHash(int x) {
        int hash = 0;
        for (int i = 0; i < TABLES; i++) {
            int index = (x >> (i * 8)) & 0xFF;
            for (int j = 0; j < TABLES; j++) {
                hash ^= mixedTables[i][index][j];
            }
        }
        return hash;
    }

    public void analyzeHash(boolean isMixed) {
        long[] bitFlips = new long[BITS + 1];
        long totalFlips = 0;
        long startTime = System.nanoTime();

        for (int x = 0; x < KEYS; x++) {
            int hash = isMixed ? mixedHash(x) : simpleHash(x);
            for (int k = 0; k < BITS; k++) {
                int xx = x ^ (1 << k);
                int hashXX = isMixed ? mixedHash(xx) : simpleHash(xx);
                int flippedBits = Integer.bitCount(hash ^ hashXX);
                bitFlips[flippedBits]++;
                totalFlips += flippedBits;
            }
        }

        long endTime = System.nanoTime();
        double avgFlips = (double) totalFlips / (KEYS * BITS);
        double chiSquare = calculateChiSquare(bitFlips);

        System.out.println(isMixed ? "Mixed Tabulation:" : "Simple Tabulation:");
        System.out.println("Average bit flips: " + avgFlips);
        System.out.println("Chi-square statistic: " + chiSquare);
        System.out.println("Time taken: " + ((endTime - startTime) / 1_000_000.0) + " ms");
        
        // Print histogram
        for (int i = 0; i <= BITS; i++) {
            System.out.printf("%d flips: %d\n", i, bitFlips[i]);
        }
        System.out.println();
    }

    private double calculateChiSquare(long[] observed) {
        double chiSquare = 0;
        long total = KEYS * BITS;
        for (int i = 0; i <= BITS; i++) {
            double expected = total * Math.pow(0.5, BITS) * binomialCoefficient(BITS, i);
            chiSquare += Math.pow(observed[i] - expected, 2) / expected;
        }
        return chiSquare;
    }

    private long binomialCoefficient(int n, int k) {
        if (k == 0 || k == n) return 1;
        return binomialCoefficient(n - 1, k - 1) + binomialCoefficient(n - 1, k);
    }

    public static void main(String[] args) {
        TabulationHashing hashing = new TabulationHashing();
        hashing.analyzeHash(false); // Simple tabulation
        hashing.analyzeHash(true);  // Mixed tabulation
    }
}